﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Threading_Timer
{
    public class Program
    {
        //Declare a _timer of type System.Threading
        private static Timer _timer;

        //Local Variable of type int
        private static int count = 1;

        static void Main(string[] args)
        {
            //Initialization of _timer 
            _timer = new Timer(x => { callTimerMethode(); }, null, Timeout.Infinite, Timeout.Infinite);
            Setup_Timer();
            Console.ReadKey();
        }

        /// <summary>
        /// This method will print timer executed time and increase the count with 1. 
        /// </summary>
        private static void callTimerMethode()
        {
            Console.WriteLine(string.Format("Timer Executed {0} times.",count));
            count=count+1;
        }

        /// <summary>
        /// This method will set the timer execution time and will change the tick time of timer.
        /// </summary>
        private static void Setup_Timer()
        {
            //DateTime currentTime = DateTime.Now;
            //DateTime timerRunningTime = new DateTime(currentTime.Year, currentTime.Month, currentTime.Day, 2, 0, 0);
            //timerRunningTime = timerRunningTime.AddDays(15);
            DateTime timerRunningTime = DateTime.Now.AddMinutes(2);

            double tickTime = (double)(timerRunningTime - DateTime.Now).TotalSeconds;

            _timer.Change(TimeSpan.FromSeconds(tickTime), TimeSpan.FromSeconds(tickTime));
        }
    }
}
